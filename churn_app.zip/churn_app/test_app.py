"""
test_app.py - local tests for Assignment 2 (Task 8).

Run:  python test_app.py

1. Predicts several sample customers through the Flask routes (the same path a browser uses).
2. Confirms the web prediction equals the prediction made directly with the saved model,
   and equals the Assignment 1 style pipeline rebuilt from the raw CSV.
3. Checks the error handling (empty, text, out-of-range, contradictory, invalid option).
"""
import json
import re

import joblib
import pandas as pd

from app import app, predict_churn, FEATURE_COLUMNS

client = app.test_client()

HIGH_RISK = {
    "gender": "Female", "SeniorCitizen": "0", "Partner": "No", "Dependents": "No", "tenure": "2",
    "PhoneService": "Yes", "MultipleLines": "No", "InternetService": "Fiber optic",
    "OnlineSecurity": "No", "OnlineBackup": "No", "DeviceProtection": "No", "TechSupport": "No",
    "StreamingTV": "No", "StreamingMovies": "No", "Contract": "Month-to-month",
    "PaperlessBilling": "Yes", "PaymentMethod": "Electronic check",
    "MonthlyCharges": "80", "TotalCharges": "160",
}
LOW_RISK = {
    "gender": "Male", "SeniorCitizen": "0", "Partner": "Yes", "Dependents": "Yes", "tenure": "60",
    "PhoneService": "Yes", "MultipleLines": "Yes", "InternetService": "DSL",
    "OnlineSecurity": "Yes", "OnlineBackup": "Yes", "DeviceProtection": "Yes", "TechSupport": "Yes",
    "StreamingTV": "No", "StreamingMovies": "No", "Contract": "Two year",
    "PaperlessBilling": "No", "PaymentMethod": "Bank transfer (automatic)",
    "MonthlyCharges": "65", "TotalCharges": "3900",
}
NO_INTERNET = dict(LOW_RISK, InternetService="No", MonthlyCharges="20", TotalCharges="1200",
                   OnlineSecurity="", OnlineBackup="", DeviceProtection="", TechSupport="",
                   StreamingTV="", StreamingMovies="")          # add-ons left empty on purpose


def web_result(form):
    r = client.post("/predict", data=form)
    html = r.get_data(as_text=True)
    label = re.search(r'class="verdict-label">([^<]+)<', html)
    chance = re.search(r"<dt>Chance of leaving</dt><dd>([\d.]+)%", html)
    return r.status_code, (label.group(1).strip() if label else None), (float(chance.group(1)) if chance else None)


print("=" * 70)
print("PART 1 - sample customers through the website route")
print("=" * 70)
for name, form in [("High-risk customer", HIGH_RISK), ("Low-risk customer", LOW_RISK),
                   ("No-internet customer (add-ons auto-filled)", NO_INTERNET)]:
    code, label, chance = web_result(form)
    print(f"{name:45s} HTTP {code} -> {label}  (chance of leaving {chance}%)")

assert web_result(HIGH_RISK)[1] == "Churn", "expected churn case did not give Churn"
assert web_result(LOW_RISK)[1] == "No Churn", "expected no-churn case did not give No Churn"

print()
print("=" * 70)
print("PART 2 - web prediction == saved model called directly == retrained pipeline")
print("=" * 70)
model = joblib.load("model.joblib")
for name, form in [("High-risk", HIGH_RISK), ("Low-risk", LOW_RISK)]:
    cust = dict(form, SeniorCitizen=int(form["SeniorCitizen"]), tenure=int(form["tenure"]),
                MonthlyCharges=float(form["MonthlyCharges"]), TotalCharges=float(form["TotalCharges"]))
    label, prob = predict_churn(cust)
    _, web_label, web_chance = web_result(form)
    # build the row by hand, independent of app.py, exactly like the Assignment 1 notebook
    row = pd.DataFrame([cust])
    row["AvgMonthlySpend"] = row["TotalCharges"] / (row["tenure"] + 1)
    row = pd.get_dummies(row).reindex(columns=FEATURE_COLUMNS, fill_value=0).astype(float)
    direct = "Churn" if int(model.predict(row)[0]) == 1 else "No Churn"
    print(f"{name:10s} web={web_label:9s} function={label:9s} direct={direct:9s}  "
          f"prob(web)={web_chance}%  prob(model)={round(model.predict_proba(row)[0][1]*100,1)}%")
    assert web_label == label == direct
    assert abs(web_chance - round(model.predict_proba(row)[0][1] * 100, 1)) < 0.11

print()
print("=" * 70)
print("PART 3 - real customers from the dataset: website vs. true label")
print("=" * 70)
df = pd.read_csv("data/WA_Fn-UseC_-Telco-Customer-Churn.csv")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
sample = pd.concat([df[df.Churn == "Yes"].sample(5, random_state=3),
                    df[df.Churn == "No"].sample(5, random_state=3)])
hits = 0
for _, r in sample.iterrows():
    form = {k: str(r[k]) for k in HIGH_RISK}
    form["MonthlyCharges"] = str(r["MonthlyCharges"]); form["TotalCharges"] = str(r["TotalCharges"])
    code, label, chance = web_result(form)
    actual = "Churn" if r["Churn"] == "Yes" else "No Churn"
    hits += label == actual
    print(f"{r['customerID']}  actual={actual:9s} website={label:9s} chance={chance}%")
print(f"Agreement with the true label on these 10 customers: {hits}/10 "
      "(the model is not perfect; its test accuracy is about 76%)")

print()
print("=" * 70)
print("PART 4 - error handling (the app must not crash)")
print("=" * 70)
cases = {
    "completely empty form": {},
    "text in a number box": dict(HIGH_RISK, tenure="abc"),
    "negative tenure": dict(HIGH_RISK, tenure="-5"),
    "decimal tenure": dict(HIGH_RISK, tenure="2.5"),
    "huge monthly charges": dict(HIGH_RISK, MonthlyCharges="999999"),
    "invalid dropdown value": dict(HIGH_RISK, Contract="Lifetime"),
    "missing one field": {k: v for k, v in HIGH_RISK.items() if k != "PaymentMethod"},
    "internet add-on given but no internet": dict(HIGH_RISK, InternetService="No"),
    "tenure 0 with total charges > 0": dict(HIGH_RISK, tenure="0"),
    "NaN typed into charges": dict(HIGH_RISK, MonthlyCharges="nan"),
}
for name, form in cases.items():
    r = client.post("/predict", data=form)
    html = r.get_data(as_text=True)
    msgs = re.findall(r'class="error-text">([^<]+)<', html)
    shown = msgs[0] if msgs else ("(page handled it)" if "Waiting" not in html else "")
    print(f"{name:42s} HTTP {r.status_code}  {shown[:70]}")
    assert r.status_code in (200, 400), name
    assert "Traceback" not in html

# "internet = No" with add-ons blank must be ACCEPTED (auto-filled by the server)
assert client.post("/predict", data=NO_INTERNET).status_code == 200
assert client.get("/nonexistent").status_code == 404
assert client.get("/predict").status_code == 200

print("\nALL TESTS PASSED")
