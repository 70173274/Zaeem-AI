"""
train_model.py  -  Assignment 2 (carry forward of Assignment 1)

Re-runs the SAME preprocessing / training pipeline as Customer_Churn_Prediction.ipynb,
selects the best model by F1-score on the churn class, and saves:
    model.joblib     -> final trained classifier
    scaler.joblib    -> StandardScaler fitted on the training data
    model_info.json  -> best model name, scaling flag, exact training column order, metrics
"""
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

RANDOM_STATE = 42
NUM_COLS = ["tenure", "MonthlyCharges", "TotalCharges", "AvgMonthlySpend"]

# 1. Load + clean (same as Assignment 1)
df = pd.read_csv("data/WA_Fn-UseC_-Telco-Customer-Churn.csv")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
df = df.drop_duplicates().drop(columns=["customerID"])

# 2. Feature engineering + one-hot encoding
data = df.copy()
data["Churn"] = data["Churn"].map({"No": 0, "Yes": 1})
data["AvgMonthlySpend"] = data["TotalCharges"] / (data["tenure"] + 1)
data_encoded = pd.get_dummies(data, drop_first=True).astype(float)
X = data_encoded.drop("Churn", axis=1)
y = data_encoded["Churn"].astype(int)

# 3. Split + scale (scaler fitted on training data only)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)
scaler = StandardScaler()
X_train_s, X_test_s = X_train.copy(), X_test.copy()
X_train_s[NUM_COLS] = scaler.fit_transform(X_train[NUM_COLS])
X_test_s[NUM_COLS] = scaler.transform(X_test[NUM_COLS])

# 4. Train the three Assignment 1 models
models = {
    "Logistic Regression": (LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE), True),
    "Decision Tree": (DecisionTreeClassifier(max_depth=5, class_weight="balanced", random_state=RANDOM_STATE), False),
    "Random Forest": (RandomForestClassifier(n_estimators=300, max_depth=8, class_weight="balanced",
                                             random_state=RANDOM_STATE, n_jobs=-1), False),
}
results = {}
for name, (model, needs_scaling) in models.items():
    model.fit(X_train_s if needs_scaling else X_train, y_train)
    Xte = X_test_s if needs_scaling else X_test
    pred, proba = model.predict(Xte), model.predict_proba(Xte)[:, 1]
    results[name] = {
        "Accuracy": round(accuracy_score(y_test, pred), 3),
        "Precision": round(precision_score(y_test, pred), 3),
        "Recall": round(recall_score(y_test, pred), 3),
        "F1-Score": round(f1_score(y_test, pred), 3),
        "ROC-AUC": round(roc_auc_score(y_test, proba), 3),
    }
    print(f"{name:20s}", results[name])

# 5. Select best model by F1 (same rule as Assignment 1) and save everything
best_name = max(results, key=lambda n: results[n]["F1-Score"])
best_model, best_scaled = models[best_name]
print("\nBest model by F1-Score:", best_name)

joblib.dump(best_model, "model.joblib")
joblib.dump(scaler, "scaler.joblib")
with open("model_info.json", "w") as f:
    json.dump({"best_model": best_name, "needs_scaling": best_scaled,
               "feature_columns": list(X.columns), "numeric_columns": NUM_COLS,
               "metrics": results}, f, indent=2)
print("Saved: model.joblib, scaler.joblib, model_info.json")
