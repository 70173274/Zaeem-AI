"""
app.py  -  Customer Churn Prediction Web Application (Flask)

Input-to-prediction flow
------------------------
1. GET  /         -> show the empty customer form (index.html)
2. POST /predict  -> read the submitted form values
3.                 -> validate them (empty / wrong type / out of range / not allowed option)
4.                 -> build ONE-row DataFrame with the same raw columns as training
5.                 -> add AvgMonthlySpend, one-hot encode, align to the training columns
6.                 -> scale the numeric columns with the SAVED scaler (if the model needs it)
7.                 -> saved Random Forest model -> Churn / No Churn + probability
8.                 -> render the result on the same page (no raw arrays shown)
"""
import json
import os

import joblib
import pandas as pd
from flask import Flask, render_template, request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))   # absolute paths work on PythonAnywhere too

app = Flask(__name__)

# ------------------------------------------------------------------ load model files once
model = joblib.load(os.path.join(BASE_DIR, "model.joblib"))
scaler = joblib.load(os.path.join(BASE_DIR, "scaler.joblib"))
with open(os.path.join(BASE_DIR, "model_info.json")) as f:
    INFO = json.load(f)

FEATURE_COLUMNS = INFO["feature_columns"]     # exact column order used in training
NUMERIC_COLUMNS = INFO["numeric_columns"]     # columns that were scaled in training
NEEDS_SCALING = INFO["needs_scaling"]         # False for Random Forest, True for Logistic Reg.

# ------------------------------------------------------------------ form definition
# Allowed values are exactly the values found in the Telco dataset.
YES_NO = ["Yes", "No"]
ADDON = ["Yes", "No", "No internet service"]

CATEGORICAL_FIELDS = {
    "gender": ("Gender", ["Female", "Male"]),
    "SeniorCitizen": ("Senior citizen (65+)", ["0", "1"]),            # shown as No / Yes
    "Partner": ("Has a partner", YES_NO),
    "Dependents": ("Has dependents", YES_NO),
    "PhoneService": ("Phone service", YES_NO),
    "MultipleLines": ("Multiple phone lines", ["Yes", "No", "No phone service"]),
    "InternetService": ("Internet service", ["DSL", "Fiber optic", "No"]),
    "OnlineSecurity": ("Online security", ADDON),
    "OnlineBackup": ("Online backup", ADDON),
    "DeviceProtection": ("Device protection", ADDON),
    "TechSupport": ("Tech support", ADDON),
    "StreamingTV": ("Streaming TV", ADDON),
    "StreamingMovies": ("Streaming movies", ADDON),
    "Contract": ("Contract type", ["Month-to-month", "One year", "Two year"]),
    "PaperlessBilling": ("Paperless billing", YES_NO),
    "PaymentMethod": ("Payment method", ["Electronic check", "Mailed check",
                                         "Bank transfer (automatic)",
                                         "Credit card (automatic)"]),
}

# name: (label, minimum, maximum, must_be_whole_number)
NUMERIC_FIELDS = {
    "tenure": ("Tenure (months)", 0, 120, True),
    "MonthlyCharges": ("Monthly charges ($)", 0, 500, False),
    "TotalCharges": ("Total charges so far ($)", 0, 100000, False),
}

INTERNET_ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                   "TechSupport", "StreamingTV", "StreamingMovies"]


# ------------------------------------------------------------------ validation
def validate_form(form):
    """Return (clean_values, errors). errors maps field name -> friendly message."""
    clean, errors = {}, {}

    for name, (label, options) in CATEGORICAL_FIELDS.items():
        value = (form.get(name) or "").strip()
        if value == "":
            errors[name] = f"Please choose a value for “{label}”."
        elif value not in options:
            errors[name] = f"“{value}” is not a valid choice for “{label}”."
        else:
            clean[name] = value

    for name, (label, low, high, whole) in NUMERIC_FIELDS.items():
        raw = (form.get(name) or "").strip()
        if raw == "":
            errors[name] = f"Please enter “{label}”."
            continue
        try:
            number = float(raw)
        except ValueError:
            errors[name] = f"“{label}” must be a number (you entered “{raw}”)."
            continue
        if number != number or number in (float("inf"), float("-inf")):
            errors[name] = f"“{label}” must be a real number."
        elif whole and number != int(number):
            errors[name] = f"“{label}” must be a whole number of months."
        elif not (low <= number <= high):
            errors[name] = f"“{label}” must be between {low} and {high}."
        else:
            clean[name] = int(number) if whole else number

    # Dataset conventions: customers without these services use fixed labels.
    # Fixing them here means the model always sees values it was trained on.
    if clean.get("PhoneService") == "No":
        clean["MultipleLines"] = "No phone service"
        errors.pop("MultipleLines", None)
    elif clean.get("MultipleLines") == "No phone service":
        errors["MultipleLines"] = "Choose Yes or No: this customer has phone service."

    if clean.get("InternetService") == "No":
        for col in INTERNET_ADDONS:
            clean[col] = "No internet service"
            errors.pop(col, None)
    else:
        for col in INTERNET_ADDONS:
            if clean.get(col) == "No internet service":
                errors[col] = (f"Choose Yes or No for “{CATEGORICAL_FIELDS[col][0]}”: "
                               "this customer has internet service.")

    # Logical check between the two money fields
    if "tenure" in clean and "TotalCharges" in clean and "MonthlyCharges" in clean:
        if clean["tenure"] == 0 and clean["TotalCharges"] != 0:
            errors["TotalCharges"] = "A brand-new customer (tenure 0) has total charges of 0."

    return clean, errors


# ------------------------------------------------------------------ prediction
def predict_churn(customer):
    """Apply the SAME preprocessing as train_model.py and return (label, probability)."""
    row = pd.DataFrame([customer])
    row["SeniorCitizen"] = row["SeniorCitizen"].astype(int)
    row["AvgMonthlySpend"] = row["TotalCharges"] / (row["tenure"] + 1)   # engineered feature
    row = pd.get_dummies(row)                                            # one-hot encoding
    row = row.reindex(columns=FEATURE_COLUMNS, fill_value=0).astype(float)  # training order
    if NEEDS_SCALING:
        row[NUMERIC_COLUMNS] = scaler.transform(row[NUMERIC_COLUMNS])

    pred = int(model.predict(row)[0])
    prob = float(model.predict_proba(row)[0][1])
    return ("Churn" if pred == 1 else "No Churn"), prob


def risk_level(prob):
    if prob >= 0.70:
        return "High"
    if prob >= 0.40:
        return "Medium"
    return "Low"


# ------------------------------------------------------------------ routes
def render_form(values=None, errors=None, result=None):
    return render_template("index.html",
                           categorical=CATEGORICAL_FIELDS,
                           numeric=NUMERIC_FIELDS,
                           values=values or {},
                           errors=errors or {},
                           result=result,
                           model_name=INFO["best_model"])


@app.route("/", methods=["GET"])
def home():
    return render_form()


@app.route("/predict", methods=["GET", "POST"])
def predict():
    if request.method == "GET":                      # someone opened /predict directly
        return render_form()

    values = request.form.to_dict()
    clean, errors = validate_form(values)
    if errors:
        return render_form(values=values, errors=errors), 400

    try:
        label, prob = predict_churn(clean)
    except Exception:                                # never crash the page
        app.logger.exception("Prediction failed")
        return render_form(values=values, errors={
            "_form": "Sorry, something went wrong while making the prediction. "
                     "Please check the values and try again."}), 500

    result = {
        "label": label,
        "churn": label == "Churn",
        "probability": round(prob * 100, 1),
        "stay_probability": round((1 - prob) * 100, 1),
        "risk": risk_level(prob),
    }
    return render_form(values=values, result=result)


@app.errorhandler(404)
def not_found(_):
    return render_form(errors={"_form": "That page does not exist. Use the form below."}), 404


@app.errorhandler(500)
def server_error(_):
    return render_form(errors={"_form": "Unexpected server error. Please try again."}), 500


if __name__ == "__main__":
    app.run(debug=True)
