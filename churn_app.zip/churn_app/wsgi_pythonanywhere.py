# ---------------------------------------------------------------------------
# PythonAnywhere WSGI configuration  (Web tab -> "WSGI configuration file")
#
# Open the WSGI file that PythonAnywhere created for your web app
# (/var/www/<your-username>_pythonanywhere_com_wsgi.py), DELETE everything in it,
# and paste the lines below.  Replace YOUR_USERNAME with your PythonAnywhere username.
# ---------------------------------------------------------------------------
import sys

project_home = "/home/YOUR_USERNAME/churn_app"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application   # PythonAnywhere looks for the name "application"
